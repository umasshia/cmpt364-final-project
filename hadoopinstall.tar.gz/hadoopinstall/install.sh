sudo addgroup hadoop
sudo adduser --ingroup hadoop hduser --gecos "First Last,RoomNumber,WorkPhone,HomePhone" --disabled-password
echo "hduser:pass123" | sudo chpasswd
sudo adduser hduser sudo
sudo cp sshd_config /etc/ssh/sshd_config
sudo service ssh restart
sudo su - hduser
