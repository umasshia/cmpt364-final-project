sudo apt-get update
sudo apt-get install openjdk-11-jdk
sudo ln -s /usr/lib/jvm/java-11-openjdk-amd64/ /usr/lib/jvm/jdk
ssh-keygen -t rsa -P ''
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
sudo cp sysctl.conf /etc/sysctl.conf
wget http://mirror.cc.columbia.edu/pub/software/apache/hadoop/common/hadoop-3.3.0/hadoop-3.3.0.tar.gz
sudo tar vxzf hadoop-3.3.0.tar.gz -C /usr/local
sudo mv /usr/local/hadoop-3.3.0 /usr/local/hadoop
sudo chown -R hduser:hadoop /usr/local/hadoop
sudo cp bashrc /home/hduser/.bashrc
source ~/.bashrc
sudo cp hosts /etc/hosts
cp hadoop-env.sh /usr/local/hadoop/etc/hadoop/hadoop-env.sh
cp core-site.xml /usr/local/hadoop/etc/hadoop/core-site.xml
cp yarn-site.xml /usr/local/hadoop/etc/hadoop/yarn-site.xml
cp mapred-site.xml /usr/local/hadoop/etc/hadoop/mapred-site.xml
cp hdfs-site.xml /usr/local/hadoop/etc/hadoop/hdfs-site.xml
cp workers /usr/local/hadoop/etc/hadoop/workers
sudo mkdir -p /home/hduser/mydata/hdfs/namenode /home/hduser/mydata/hdfs/datanode
sudo chown -R hduser:hadoop /home/hduser/mydata
cd
